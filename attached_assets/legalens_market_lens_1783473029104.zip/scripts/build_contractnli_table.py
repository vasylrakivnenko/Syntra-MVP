"""Build a REAL NDA table from ContractNLI (CC BY 4.0).

Draws from ContractNLI's SEC-sourced subset (document_type sec-text/sec-html) —
already-public filings, cleanest provenance — extracts each via gpt-4.1, and
builds a real (if small) market table. Every row is a genuine NDA.

Env: AZURE_OPENAI_KEY, CNLI_ZIP (path to contract-nli.zip).
"""

from __future__ import annotations

import json
import os
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from market_lens.build_table import build_table  # noqa: E402
from market_lens.extract import extraction_to_record  # noqa: E402
from market_lens.providers.azure_openai import extract_text  # noqa: E402
from market_lens.schema_loader import coerce_row, load_schema  # noqa: E402
from market_lens.stats import off_market_rank, segment, univariate  # noqa: E402

N_DOCS = 200
MAX_CHARS = 30000
REC_DIR = ROOT / "records_cnli"
TABLE_DIR = ROOT / "contractnli_table"
LICENSE_CLASS = "cc_by_4.0"  # corrected: ContractNLI is CC BY 4.0, not NC


def select_docs(zip_path: str, n: int) -> list[dict]:
    """SEC-sourced NDAs (cleanest provenance) across all splits, deduped by id.
    Order (train, then dev, then test) is stable so the first 100 match what was
    already extracted -> idempotent skip pays only for the new docs."""
    z = zipfile.ZipFile(zip_path)
    out: list[dict] = []
    seen: set = set()
    for split in ("train.json", "dev.json", "test.json"):
        d = json.loads(z.read(f"contract-nli/{split}"))
        for doc in d["documents"]:
            if doc.get("document_type") not in ("sec-text", "sec-html"):
                continue
            if doc["id"] in seen:
                continue
            seen.add(doc["id"])
            out.append(doc)
            if len(out) >= n:
                return out
    return out


def extract_all(docs: list[dict]) -> list[Path]:
    REC_DIR.mkdir(exist_ok=True)
    schema = load_schema()
    written: list[Path] = []
    for i, doc in enumerate(docs, 1):
        name = f"cnli_{doc['id']}"
        if (REC_DIR / f"{name}.json").exists():  # idempotent: don't re-extract
            written.append(REC_DIR / f"{name}.json")
            continue
        for attempt in (1, 2):
            try:
                ext = extract_text(doc["text"][:MAX_CHARS], source_name=name,
                                   schema=schema, license_class=LICENSE_CLASS)
                ext.meta["document_type"] = doc.get("document_type")
                ext.meta["source_url"] = doc.get("url")
                (REC_DIR / f"{name}.json").write_text(
                    json.dumps(extraction_to_record(ext), indent=2))
                written.append(REC_DIR / f"{name}.json")
                print(f"  [extract {i:2d}/{len(docs)}] {name}  coverage {ext.meta['coverage']:.0%}", flush=True)
                break
            except Exception as e:
                if attempt == 1:
                    time.sleep(3)
                else:
                    print(f"  [extract {i:2d}] {name} FAILED: {str(e)[:140]}", flush=True)
    return written


def report() -> None:
    import sqlite3
    schema = load_schema()
    con = sqlite3.connect(TABLE_DIR / "market.sqlite")
    con.row_factory = sqlite3.Row
    rows = [coerce_row(schema, dict(r)) for r in con.execute("SELECT * FROM ndas")]
    con.close()

    n = len(rows)
    mut, uni = segment(rows, True), segment(rows, False)
    print(f"\n{'='*74}\nREAL ContractNLI table: {n} NDAs  (mutual={len(mut)}, unilateral={len(uni)})")
    print(f"{'='*74}\nUnivariate — clause prevalence")
    u = univariate(schema, rows)
    for f in schema.fields:
        s = u[f.id]
        if f.type in ("bool", "enum"):
            freq = ", ".join(f"{k} {v:.0%}" for k, v in sorted(s["freq"].items(), key=lambda x: -x[1]))
            print(f"  {f.id:<32} cov {s['coverage']:3.0%} | {freq}")
        else:
            vals = s.get("values", [])
            med = vals[len(vals) // 2] if vals else None
            print(f"  {f.id:<32} cov {s['coverage']:3.0%} | n={len(vals)} median={med}")

    # Off-Market Index v1.1 (magnitude-weighted surprise, rank-normalized).
    print(f"\n{'='*74}\nOff-Market Index v1.1 — most off-market NDAs per segment")
    print(f"{'='*74}")
    for label, mutual_val in (("mutual", True), ("unilateral", False)):
        seg = segment(rows, mutual_val)
        scores = off_market_rank(schema, seg)
        print(f"\n[{label} segment, N={len(seg)}]")
        if scores is None:
            print("  insufficient_data (segment below N>=30 floor)")
            continue
        for om in scores[:3]:
            print(f"  {om.doc.get('_source_doc')}: Off-Market Index {om.index}/100  (raw surprise {om.raw})")
            for combo, obs, exp in om.contributions[:3]:
                print(f"      expected ~{exp:.1f}, observed {obs}   {'  +  '.join(combo)}")


def main() -> None:
    zip_path = os.environ["CNLI_ZIP"]
    print("### 1. select SEC-sourced NDAs from ContractNLI", flush=True)
    docs = select_docs(zip_path, N_DOCS)
    print(f"selected {len(docs)} NDAs (document_type sec-text/sec-html)\n", flush=True)

    print("### 2. extract via gpt-4.1", flush=True)
    recs = extract_all(docs)
    print(f"extracted {len(recs)} records\n", flush=True)

    print("### 3. build table", flush=True)
    print(json.dumps(build_table(REC_DIR, TABLE_DIR, schema=load_schema()), indent=2), flush=True)

    print("\n### 4. report", flush=True)
    report()
    print("\nDONE", flush=True)


if __name__ == "__main__":
    main()
