"""Build the first REAL (tiny) LegaLens table from SEC EDGAR NDAs.

Pipeline, all real:
  1. harvest  — EDGAR full-text search for confidentiality-agreement exhibits,
                fetch each, strip to text, keep only ones that look like a
                genuine NDA, dedupe by filer.
  2. extract  — gpt-4.1 (Azure) -> one typed record per doc (records_real/).
  3. build    — records -> market table (market_table_real/).
  4. report   — univariate frequencies per segment; Off-Market will honestly
                report insufficient_data (segments below the N floor).

No fabrication: every row is a real filed agreement. Needs AZURE_OPENAI_KEY.
"""

from __future__ import annotations

import json
import re
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from market_lens.build_table import build_table  # noqa: E402
from market_lens.extract import extraction_to_record  # noqa: E402
from market_lens.providers.azure_openai import extract_file  # noqa: E402
from market_lens.schema_loader import coerce_row, load_schema  # noqa: E402
from market_lens.stats import segment, univariate  # noqa: E402

UA_EDGAR = {"User-Agent": "LegaLens research vasyl@law.stanford.edu"}
TARGET = 18
NDA_DIR = ROOT / "ndas"
REC_DIR = ROOT / "records_real"
TABLE_DIR = ROOT / "market_table_real"

QUERIES = [
    '"mutual non-disclosure agreement"',
    '"non-disclosure agreement"',
    '"confidentiality agreement"',
    '"mutual confidentiality agreement"',
]
HALLMARKS = ["confidential", "disclos", "recipient", "return", "governing",
             "injunctive", "term", "party", "obligation"]


def _get(url: str, headers: dict, timeout: int = 60) -> str:
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def strip_html(s: str) -> str:
    s = re.sub(r"(?is)<(script|style).*?</\1>", " ", s)
    s = re.sub(r"(?s)<[^>]+>", " ", s)
    for a, b in [("&nbsp;", " "), ("&amp;", "&"), ("&quot;", '"'),
                 ("&#39;", "'"), ("&rsquo;", "'"), ("&ldquo;", '"'), ("&rdquo;", '"')]:
        s = s.replace(a, b)
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n\s*\n\s*\n+", "\n\n", s)
    return s.strip()


def looks_like_nda(txt: str) -> bool:
    low = txt.lower()
    if not (1500 <= len(txt) <= 60000):
        return False
    if "confidential" not in low:
        return False
    if not any(k in low for k in ("non-disclosure", "nondisclosure", "confidentiality agreement")):
        return False
    if sum(k in low for k in HALLMARKS) < 5:
        return False
    return "agreement" in low[:2000]


def harvest(target: int) -> list[Path]:
    NDA_DIR.mkdir(exist_ok=True)
    kept: list[Path] = []
    seen_cik: set[str] = set()
    seen_doc: set[str] = set()
    for q in QUERIES:
        if len(kept) >= target:
            break
        for frm in (0, 10, 20):
            if len(kept) >= target:
                break
            params = urllib.parse.urlencode({"q": q, "forms": "8-K", "from": frm})
            try:
                d = json.loads(_get(f"https://efts.sec.gov/LATEST/search-index?{params}", UA_EDGAR))
            except Exception as e:
                print(f"  [fts] query {q!r} from={frm} failed: {e}", flush=True)
                continue
            for h in d.get("hits", {}).get("hits", []):
                if len(kept) >= target:
                    break
                src = h.get("_source", {})
                ft = (src.get("file_type") or "")
                if not ft.upper().startswith("EX"):
                    continue
                _id = h.get("_id", "")
                if ":" not in _id or _id in seen_doc:
                    continue
                seen_doc.add(_id)
                adsh, fname = _id.split(":", 1)
                ciks = src.get("ciks") or ([src["cik"]] if src.get("cik") else [])
                if not ciks:
                    continue
                cik = str(ciks[0]).lstrip("0") or ciks[0]
                if cik in seen_cik:  # one doc per filer, for variety
                    continue
                url = (f"https://www.sec.gov/Archives/edgar/data/{cik}/"
                       f"{adsh.replace('-', '')}/{fname}")
                try:
                    raw = _get(url, UA_EDGAR)
                    time.sleep(0.15)  # be polite to EDGAR
                except Exception as e:
                    print(f"  [doc] {url} failed: {e}", flush=True)
                    continue
                txt = raw if fname.endswith(".txt") else strip_html(raw)
                txt = strip_html(txt) if ("<" in txt and ">" in txt) else txt
                if not looks_like_nda(txt):
                    continue
                seen_cik.add(cik)
                out = NDA_DIR / f"nda_{len(kept):02d}_cik{cik}.txt"
                out.write_text(txt)
                # store source url alongside for provenance
                (NDA_DIR / f"{out.stem}.source").write_text(url)
                kept.append(out)
                print(f"  [keep {len(kept):2d}] {out.name}  ({len(txt)} chars)  {url}", flush=True)
    return kept


def extract_all(docs: list[Path]) -> list[Path]:
    REC_DIR.mkdir(exist_ok=True)
    schema = load_schema()
    written: list[Path] = []
    for i, doc in enumerate(docs, 1):
        for attempt in (1, 2):
            try:
                ext = extract_file(doc, schema=schema, license_class="unknown")
                rec = extraction_to_record(ext)
                src = (NDA_DIR / f"{doc.stem}.source")
                rec["_meta"]["source_url"] = src.read_text() if src.exists() else None
                p = REC_DIR / f"{doc.stem}.json"
                p.write_text(json.dumps(rec, indent=2))
                written.append(p)
                print(f"  [extract {i:2d}/{len(docs)}] {doc.name}  coverage {ext.meta['coverage']:.0%}", flush=True)
                break
            except Exception as e:
                if attempt == 1:
                    print(f"  [extract {i:2d}] {doc.name} retry after: {str(e)[:120]}", flush=True)
                    time.sleep(3)
                else:
                    print(f"  [extract {i:2d}] {doc.name} FAILED: {str(e)[:160]}", flush=True)
    return written


def report() -> None:
    schema = load_schema()
    import sqlite3
    con = sqlite3.connect(TABLE_DIR / "market.sqlite")
    con.row_factory = sqlite3.Row
    rows = [coerce_row(schema, dict(r)) for r in con.execute("SELECT * FROM ndas")]
    con.close()

    n = len(rows)
    mut = segment(rows, True)
    uni = segment(rows, False)
    print(f"\n{'='*72}\nREAL LegaLens table: {n} NDAs  (mutual={len(mut)}, unilateral={len(uni)})")
    print(f"{'='*72}\nUnivariate — clause prevalence across the whole (tiny) population")
    u = univariate(schema, rows)
    for f in schema.fields:
        s = u[f.id]
        cov = s["coverage"]
        if f.type in ("bool", "enum"):
            freq = ", ".join(f"{k} {v:.0%}" for k, v in sorted(s["freq"].items(), key=lambda x: -x[1]))
            print(f"  {f.id:<32} cov {cov:3.0%}  | {freq}")
        else:
            vals = s.get("values", [])
            med = vals[len(vals)//2] if vals else None
            print(f"  {f.id:<32} cov {cov:3.0%}  | n={len(vals)} median={med}")
    print(f"\nNote: Off-Market Index needs segment N >= 30 (see stats.MIN_SEGMENT_N);")
    print(f"at N={n} it will correctly report insufficient_data — the small-N guard working.")


def main() -> None:
    print("### 1. harvest real NDAs from EDGAR", flush=True)
    docs = sorted(NDA_DIR.glob("nda_*.txt"))
    if len(docs) < TARGET:
        docs = harvest(TARGET)
    print(f"harvested {len(docs)} candidate NDAs\n", flush=True)

    print("### 2. extract via gpt-4.1", flush=True)
    recs = extract_all(docs)
    print(f"extracted {len(recs)} records\n", flush=True)

    print("### 3. build market table", flush=True)
    summary = build_table(REC_DIR, TABLE_DIR, schema=load_schema())
    print(json.dumps(summary, indent=2), flush=True)

    print("\n### 4. report", flush=True)
    report()
    print("\nDONE", flush=True)


if __name__ == "__main__":
    main()
