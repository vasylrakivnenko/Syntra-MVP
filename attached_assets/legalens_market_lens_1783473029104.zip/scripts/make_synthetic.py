"""Generate synthetic extraction records for offline pipeline verification.

NOT part of the product — this fabricates a market table so the build_table /
stats / score legs can be exercised without the API. Real records come from
`market_lens.build_table extract`.

    python scripts/make_synthetic.py ./records --n 200 --seed 7
"""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

# import the real schema so synthetic data always matches the current fields
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from market_lens.schema_loader import PERPETUAL_SENTINEL, load_schema  # noqa: E402


def _sample_value(f, rng: random.Random):
    # ~8% of the time, leave undetermined (null) to exercise coverage handling
    if rng.random() < 0.08:
        return None
    if f.type == "bool":
        return rng.random() < 0.6  # most clauses present more often than not
    if f.type == "enum":
        return rng.choice(f.enum)
    if f.type == "numeric_months":
        # mix of common durations + occasional perpetual
        if rng.random() < 0.12:
            return PERPETUAL_SENTINEL
        return rng.choice([12, 18, 24, 24, 24, 36, 36, 48, 60])
    return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("out_dir")
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--license-class", default="asset_eligible")
    args = ap.parse_args()

    rng = random.Random(args.seed)
    schema = load_schema()
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    for i in range(args.n):
        row = {f.id: _sample_value(f, rng) for f in schema.fields}
        rec = {
            **row,
            "_meta": {
                "source_doc": f"synthetic_{i:04d}.txt",
                "schema_version": schema.version,
                "model": "synthetic",
                "license_class": args.license_class,
                "coverage": round(sum(v is not None for v in row.values()) / len(row), 4),
            },
            "_evidence": {f.id: None for f in schema.fields},
        }
        (out / f"synthetic_{i:04d}.json").write_text(json.dumps(rec, indent=2))

    print(f"wrote {args.n} synthetic records to {out}")


if __name__ == "__main__":
    main()
