# Market Lens (NDA) — walking skeleton (v0.1)

A statistical layer that types each NDA into a market-wide table, then scores a
new NDA against the population: per-field percentiles (parity) and an
**Off-Market Index** built from rare clause *combinations* (the differentiator).

No UI. File path in, results printed:

```
python -m market_lens.score path/to/nda.pdf --table ./market_table
```

This is the **walking skeleton** deliberately built *before* the corpus weekend:
it exercises the whole pipe on a handful of docs to de-risk the two riskiest
assumptions (whole-doc extraction reliability, `null` ≠ `absent` discipline) for
~$1 before spending on a 5k-doc run.

## Layout

```
market_lens/
  schema/nda-schema.yaml   D1 — starter ~18-field core (expand to 80–120), schema_version pinned
  schema_loader.py         load schema -> JSON Schema for extraction + tokenizers + type coercion
  extract.py               D3 — one whole-doc Claude call, structured output, evidence spans
  build_table.py           D5 — records -> parquet + sqlite; enforces the license guard
  stats.py                 D6 — univariate percentiles + Off-Market Index v1 (co-occurrence rarity)
  score.py                 the "product": extract -> row -> print percentiles + off-market
scripts/make_synthetic.py  offline pipeline check (fabricates a market table; NOT product)
```

## Quickstart

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 1. offline sanity check — no API key needed
python scripts/make_synthetic.py ./records --n 200
python -m market_lens.build_table build ./records ./market_table
python -m market_lens.score --record ./records/synthetic_0000.json --table ./market_table

# 2. real run (needs ANTHROPIC_API_KEY or `ant auth login`)
python -m market_lens.build_table extract ./ndas ./records --license-class asset_eligible
python -m market_lens.build_table build ./records ./market_table
python -m market_lens.score ./new_nda.pdf --table ./market_table
```

## Design decisions baked in

- **Off-Market Index v1 = 2- and 3-way clause-combination rarity**, explainable by
  construction ("broad CI + zero carve-outs + perpetual survival: 0.9% of segment").
  The ML scorer (isolation forest) is **deferred to v2.1** and must beat this
  baseline on Precision@20 to earn its opacity. Mahalanobis was rejected (its
  normality assumption fails on binary/enum fields).
- **Segment on mutuality only.** Industry is a *field*, not a scoring segment —
  over-segmentation manufactures false outliers. See `stats.MIN_SEGMENT_N`.
- **Transparent small-N failure.** The rules layer is *not* bulletproof at N≈300;
  a combo can be rare just because the segment is small. Floors
  (`MIN_SEGMENT_N`, `MIN_MARGINAL_SUPPORT`) gate scoring, and sub-threshold
  segments are labelled `insufficient_data`, never `off-market`.
- **`null` ≠ `absent`.** The extraction schema permits `null` on every field so
  the model distinguishes "clause absent" (`false`) from "could not determine"
  (`null`); nulls are excluded from stats and counted as coverage.
- **License guard.** `build_table` drops rows tagged `license_class == "eval_only"`
  (e.g. ContractNLI-derived, CC BY-NC) from the asset table — schema inspiration
  and eval only, never the commercial statistics. CUAD (CC BY 4.0) is clean; the
  MCC (Material Contracts Corpus, Nyarko/Stanford) terms need one explicit read
  before the moat thesis leans on it.

## Determinism note (spec §5 correction)

The spec says "temperature 0". Modern models (Sonnet 5 / Opus 4.8) **reject the
`temperature` parameter** (HTTP 400). The determinism substitute — and what
`extract.py` uses — is **structured outputs + `thinking: disabled`**. Extraction
model defaults to `claude-sonnet-5` (config constant `MODEL` in `extract.py`),
swappable to `claude-opus-4-8` if the golden-set gate shows the long-tail fields
need it.

## Status

- Offline path (schema → table → percentiles → Off-Market Index) is verified
  end-to-end on synthetic data.
- **The live extraction call (`extract.py`) is unverified** — it needs an API
  key. It is correct-by-construction against the current SDK, but the first real
  action should be the golden-set gate on 50–100 hand-labelled NDAs (stratified
  to over-sample rare clauses; per-field accuracy reported with support counts;
  fields with <5 positives labelled "unvalidated").
