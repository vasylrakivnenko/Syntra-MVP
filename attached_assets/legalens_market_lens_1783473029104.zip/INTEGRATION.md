# Market Lens — integration guide (for the Replit agent)

Market Lens is a self-contained Python module that turns an NDA into a typed row
and scores it against a market table. It has **no web framework and no UI** — it's
a library + CLIs you wire into the host app's flow.

## What's in this package

```
market_lens/                 the library (import this)
  schema/nda-schema.yaml     typed field schema (bump schema_version on change)
  schema_loader.py           schema -> JSON Schema + tokenizers + type coercion
  extract.py                 Anthropic extraction backend + Extraction dataclass
  providers/
    azure_openai.py          Azure OpenAI backend  (gpt-4.1)   <-- used to build the shipped table
    hyperbolic.py            Hyperbolic backend    (open models)
  build_table.py             records -> parquet + sqlite (+ license guard)
  stats.py                   univariate percentiles + Off-Market Index (v1.1)
  score.py                   CLI: extract a doc + print scoring
scripts/                     one-off drivers (corpus build, synthetic fixture)
records_cnli/                200 REAL extracted NDA records (ContractNLI, CC BY 4.0)
contractnli_table/           the built market table (market.sqlite + market.parquet)
ndas/nextgroup_mnda.txt      one sample real NDA (for an extract demo)
requirements.txt             deps
```

The package ships with a **real, prebuilt 200-NDA table** (`contractnli_table/`), so
scoring works out of the box with no API calls. Extraction of *new* NDAs needs a
model provider (below). See `DATA_ATTRIBUTION.md` — the shipped data is CC BY 4.0.

## Install

```bash
pip install -r requirements.txt   # anthropic, PyYAML, pandas, pyarrow
```

Python 3.10+ (uses `match`/union types). No network needed for scoring against the
shipped table; only extraction of new documents calls a provider.

## Environment variables (extraction only)

Pick ONE provider. Nothing is hardcoded; no keys ship in the code.

| Provider | Env vars | Notes |
|---|---|---|
| **Azure OpenAI** (used to build the shipped table) | `AZURE_OPENAI_ENDPOINT` (full `chat/completions?api-version=...` URL), `AZURE_OPENAI_KEY`, `AZURE_OPENAI_MODEL` (opt, default `gpt-4.1`) | `market_lens.providers.azure_openai` |
| **Anthropic** | `ANTHROPIC_API_KEY` | `market_lens.extract` (structured outputs + thinking disabled) |
| **Hyperbolic** | `HYPERBOLIC_API_KEY` | `market_lens.providers.hyperbolic` (streaming; open models) |

Set these in Replit **Secrets**, not in code.

## The two integration points

### 1. Extract an NDA → typed row + evidence

```python
from market_lens.providers.azure_openai import extract_file, extract_text

ext = extract_file("path/to/nda.pdf")          # or extract_text(raw_text, source_name="...")
ext.row          # {field_id: value}  (bool / enum str / months float / None)
ext.evidence     # {field_id: verbatim quote or None}
ext.meta         # {coverage, model, schema_version, license_class, ...}
```

`null != absent`: a bool `False` means the clause is absent; `None` means "could not
determine" (excluded from stats, counted in `coverage`).

### 2. Score a row against the market table

```python
import sqlite3
from market_lens.schema_loader import load_schema, coerce_row
from market_lens.stats import segment, univariate, percentile, off_market_rank

schema = load_schema()
con = sqlite3.connect("contractnli_table/market.sqlite"); con.row_factory = sqlite3.Row
rows = [coerce_row(schema, dict(r)) for r in con.execute("SELECT * FROM ndas")]

seg = segment(rows, target_row["mutual"])       # segment on mutuality only
uni = univariate(schema, seg)                    # per-field prevalence / distribution
ranked = off_market_rank(schema, seg)            # Off-Market Index per doc (or None if N<30)
```

Or just run the bundled CLI end to end:

```bash
python -m market_lens.score ndas/nextgroup_mnda.txt --table ./contractnli_table
python -m market_lens.score --record records_cnli/cnli_469.json --table ./contractnli_table  # no API
```

## Wiring into the host flow (suggested)

1. On an inbound NDA → call `extract_*` → get `ext.row`.
2. Segment the shipped table by `ext.row["mutual"]`, compute `univariate` + `off_market_rank`.
3. Return per-field percentiles + the Off-Market contributions as **statistical context,
   not legal advice** — feed it to the routing signal; never replace the attorney threshold.

## Load-bearing caveats (do not paper over)

- **Off-Market Index v1.1 params are unvalidated.** `stats.MIN_MARGINAL_V11` / `EXP_MIN`
  were tuned once on this 200-NDA sample. The real gate is an attorney Precision@20
  pass (spec D7) before the ranking is trusted in-product.
- **`filter(NDA)` needs a classifier.** If the host ingests arbitrary contracts, run an
  LLM "is this a standalone NDA?" gate first — substring filtering runs at ~11% precision
  (see the classifier pattern in `scripts/build_real_table.py`'s findings).
- **Segment on mutuality only.** Industry is a field, not a scoring segment.
- **`score.py`'s single-doc path uses the older saturating index**; the working v1.1
  (`off_market_rank`) operates on a whole segment. To score a *new* doc with v1.1, store
  the segment's raw-surprise distribution and rank-normalize the new doc against it.
