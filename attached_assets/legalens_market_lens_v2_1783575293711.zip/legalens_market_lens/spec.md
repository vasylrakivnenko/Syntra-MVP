# Market Lens — integration spec for the Replit agent

This document is the single source of truth for integrating the `market_lens`
Python package into the host product. It supersedes the older
`INTEGRATION.md` (still included for the low-level extraction/scoring API
reference) by adding the evidence-layer and TabPFN pieces built after that
doc was written.

## 1. What this is

`market_lens` is a self-contained Python library. It has **no web framework,
no UI, no database of its own** — you import it (or shell out to its CLIs)
from your own backend. Given an NDA, it produces:

1. A **typed extraction** — 18 fields (mutual/unilateral, carve-outs,
   survival period, governing law, dispute resolution, etc.), each with a
   verbatim evidence quote from the document.
2. Two independent **rarity signals per field** — how unusual is this
   specific clause value compared to ~1,150 real, licensed NDAs — computed
   two different ways on purpose (see §4).
3. **Nothing else.** It does not write the human-facing report. That's step
   3 below, and it's explicitly **your job, not this package's** — see §3.

Every statistic this package produces is labeled, in code and in output,
**"statistical context, not legal advice."** Keep that framing in whatever
you build on top.

## 2. What's in this package, and what's deliberately left out

```
market_lens/                  the library — import this
  schema/nda-schema.yaml       the 18-field schema (bump schema_version on change)
  schema_loader.py             schema -> pydantic models, type coercion, bucketing
  extract.py                   Anthropic extraction (messages.parse, structured outputs)
  batch.py                     Anthropic Message Batches API — bulk extraction, ~50% cheaper
  providers/azure_openai.py    Azure OpenAI backend (gpt-4.1) — used to build the shipped table
  providers/hyperbolic.py      Hyperbolic backend (open models)
  build_table.py               records -> parquet + sqlite (+ license allowlist, dedup)
  stats.py                     univariate rarity + Off-Market Index (rule-based, v1.1)
  score.py                     CLI: human-readable per-NDA report (for a human running it directly)
  evidence.py                  the machine-readable evidence bundle -- THE main integration point
  tabpfn_score.py              OPTIONAL: live TabPFN conditional-probability signal
market_table_combined/        the PREBUILT market table (1,158 real, licensed NDAs)
  market.sqlite                the typed rows
  market.parquet                same data, columnar
  omx_reference.json            persisted reference for scoring NEW docs without rescoring the corpus
ndas/nextgroup_mnda.txt       one sample real NDA (for a demo extraction)
DATA_ATTRIBUTION.md           licensing detail for every source in the table
README.md, INTEGRATION.md     lower-level background (schema design, CLI basics)
requirements.txt
```

**Deliberately NOT included** (this is a clean handoff of the runtime
library + its data asset, not the research/corpus-building repo):

- Raw per-source record dumps (`records_cnli/`, `records_edgar/`, etc.) and
  harvest/crosscheck scripts. Those built `market_table_combined/` — you
  don't need them to *use* the table, only to *grow* it, which stays on the
  LegaLens side. If the table ever needs rebuilding, that happens upstream
  and a fresh `market_table_combined/` gets handed off again.
- `tabpfn_results/` (pilot/analysis artifacts) — useful for us deciding
  whether TabPFN is worth keeping, not needed for the library to run.
- Anything with a live API key in it. **Never commit `.env` or hardcode
  keys.** See §5.

## 3. The pipeline, and who owns which step

```
1. EXTRACT   market_lens.extract / market_lens.batch
             NDA text -> typed row + evidence quotes
             (this package, already built)

2. SCORE     market_lens.evidence.build_evidence
             typed row + market_table_combined -> per-field evidence bundle:
             rule-based rarity (always) + TabPFN probability (optional)
             (this package, already built)

3. SYNTHESIZE  <-- YOUR CODE, ON REPLIT, NOT IN THIS PACKAGE
             evidence bundle + full doc text + evidence quotes
             -> the human-facing Market Position Report
             (one LLM call you write and own)
```

Step 3 is intentionally not in this package. The reasoning: step 3 needs the
*actual clause text* alongside the statistics to make judgment calls a
formula can't (see §6) — that's a product-specific prompt you'll iterate on
independently of this library's release cycle. Don't try to import step 3
from here; there isn't one.

## 4. Step 2 in detail: the evidence bundle

Call this after extraction, before your synthesis LLM call:

```python
from market_lens.schema_loader import load_schema, coerce_row
from market_lens.evidence import build_evidence

schema = load_schema()
# `extracted_row` = the dict you got back from market_lens.extract (field_id -> value)
target_row = coerce_row(schema, extracted_row)

bundle = build_evidence(schema, target_row, "./market_table_combined")
```

Or via the CLI (if your integration shells out instead of importing Python
directly):

```bash
python -m market_lens.evidence --record path/to/extracted_record.json --table ./market_table_combined
# -> JSON on stdout
```

**Bundle shape:**

```jsonc
{
  "segment": "mutual",              // or "unilateral" / "all"
  "segment_n": 628,                 // size of the comparison population
  "off_market_index": 27.4,         // 0-100, whole-document rarity (rule-based, v1.1)
  "off_market_status": "scored",    // or "insufficient_data" (segment too small to score)
  "fields": {
    "share_with_affiliates": {
      "value": false,
      "rule_univariate": { "share": 0.18 },   // 18% of comparable NDAs share this value
      "rule_combo": {                          // this field's rarest flagged combination, if any
        "combo": ["carveout_required_by_law=true", "share_with_affiliates=false"],
        "observed": 98, "expected": 129.3, "pvalue": 0.002
      },
      "tabpfn_p_obs": null    // populated only if you pass tabpfn_p_obs (see §7); else always null
    },
    // ... one entry per schema field, ALWAYS -- not just the "unusual" ones
  }
}
```

Every field is present whether or not anything is flagged. **Do not filter
in this layer** — filtering/prioritizing which clauses are worth a lawyer's
attention is exactly the judgment step 3 should make with full context, not
a threshold buried in step 2.

## 5. Setup

```bash
pip install -r requirements.txt
```

Environment variables (Secrets in Replit, never in code or committed files):

| Var | Required for | Notes |
|---|---|---|
| `ANTHROPIC_API_KEY` | extraction (`market_lens.extract`, `market_lens.batch`) | `sk-ant-api03-...` |
| `TABPFN_TOKEN` | the optional TabPFN signal (`market_lens.tabpfn_score`) | omit entirely to skip TabPFN — nothing else breaks |

Python 3.10+.

## 6. Why two independent signals instead of one score

`rule_univariate` and `tabpfn_p_obs` (when both present) frequently
**disagree** — in our internal testing, their "top-3 most surprising fields"
for a document overlapped only ~60% of the time. That disagreement is not
noise to average away — it's a real signal. When both a transparent
frequency count and a learned conditional-probability model flag the same
clause, that's a well-supported outlier. When they diverge, that's exactly
where the actual clause language matters, and exactly the kind of judgment
call your step-3 LLM should make explicitly (and say so — "the two
statistical signals disagree here" is a legitimate, useful thing to tell a
lawyer), not something to resolve by picking a winner in code.

Concretely, prompt your step-3 synthesis with, per field: the value, the
evidence quote, both rarity numbers, and whether they agree — and ask the
model to flag disagreement as "worth a second look," not silently pick one.

## 7. TabPFN: optional, and the pattern that keeps it cheap

TabPFN is a live, network-dependent, learned signal — not required for
anything else here to work. Skip it entirely by never calling
`tabpfn_score` and passing `tabpfn_p_obs=None` (the default) to
`build_evidence`.

If you do want it, there are two operations with very different costs —
**do not confuse them**:

```python
from market_lens.tabpfn_score import fit_all_fields, score_new_doc

# EXPENSIVE (18 network calls, uploads ~1,150 rows per field). Call this
# ONCE per process lifetime, or on a schedule whenever market_table_combined
# is refreshed. NEVER call this per incoming NDA.
fitted = fit_all_fields("./market_table_combined")   # keep this in memory

# CHEAP. Call this once per incoming NDA -- reuses the already-fitted models.
tabpfn_result = score_new_doc(schema, fitted, target_row)

bundle = build_evidence(schema, target_row, "./market_table_combined",
                         tabpfn_p_obs=tabpfn_result)
```

If your Replit deployment sleeps on idle and loses memory, you'll eat one
re-fit on wake — that's fine, it's still per-cold-start, not per-request.

**Reliability note:** every live TabPFN call is a dependency on an external
service. The rule-based signal has none. If TabPFN is unavailable or slow,
degrade gracefully — score with `tabpfn_p_obs=None` rather than failing the
whole report.

## 8. Who sees what: lawyer view vs. client view

The raw statistics (`rule_univariate` shares, `tabpfn_p_obs`,
`off_market_index`) are **for the reviewing lawyer**, not necessarily the
end client. Recommended split:

- **Lawyer-facing view:** full evidence bundle + step-3 synthesis + the
  actual numbers, so the statistical claims are checkable, not asserted.
  "12% of comparable NDAs allow this" should be visible and verifiable,
  not just a hidden input to a score.
- **Client-facing view (if any):** the step-3 synthesis's plain-language
  output only — verdict and explanation, no raw statistics, no model
  internals. Whether to show clients anything at all beyond a summary
  status is your call; the raw numbers specifically should not need to
  travel that far.

Never present either the rule-based or TabPFN score alone as "this clause
is bad" — both are calibrated against `market_table_combined`'s current
population, which is real but not exhaustive (see DATA_ATTRIBUTION.md), and
neither has been validated against actual attorney judgment (no
Precision@20 gate has been run). Keep "statistical context, not legal
advice" in every surface that shows these numbers.

## 9. If the table needs to grow

`market_table_combined/` is a snapshot. If LegaLens hands you a refreshed
one later, it's a drop-in replacement — same file names, same schema
version (check `omx_reference.json`'s `schema_version` matches
`market_lens.schema_loader.load_schema().version`; `build_evidence` and
`score_against_reference` both refuse a mismatch rather than silently
scoring against the wrong schema). If you're running `tabpfn_score.fit_all_fields`,
re-fit after any table refresh — the old fitted models reference the old
population.
